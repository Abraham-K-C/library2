# orden-ms

Microservicio de ordenes con Spring Boot, MySQL y Kafka.

Publica eventos `orden.creada` en el topic:

```text
orden-eventos
```

## Datos

```text
Group Id:     com.upeu
Artifact Id:  orden-ms
Package Name: com.upeu.ordenms
```

## Puertos

| Recurso | DEV | PROD |
|---|---:|---:|
| App | 19051 | 29051 |
| MySQL | 19050 | 29050 |

Kafka:

- dev host: `localhost:41092`
- prod Docker: `kafka:9092`

## Base de datos

```text
db_orden_ms
```

## Archivos

- `docker-compose-dev.yml`: MySQL dev
- `docker-compose.yml`: app + MySQL prod
- `.env`: variables prod
- `src/main/resources/application.yml`: nombre de app, import de Config Server y topics
- `../../infra/config-repo/orden-ms-dev.yml`: config dev centralizada
- `../../infra/config-repo/orden-ms-prod.yml`: config prod centralizada

## Levantar DEV

Primero infraestructura dev:

```powershell
cd C:\ms1\ProyectosMS2026\infra\config-server
.\mvnw.cmd spring-boot:run
```

En otra terminal:

```powershell
cd C:\ms1\ProyectosMS2026\infra\registry-server
.\mvnw.cmd spring-boot:run
```

Luego Kafka dev:

```powershell
cd C:\ms1\ProyectosMS2026\kafka
docker compose -f docker-compose-dev.yml up -d
```

Luego MySQL dev:

```powershell
cd C:\ms1\ProyectosMS2026\services\orden-ms
docker compose -f docker-compose-dev.yml up -d
```

Ejecutar la app:

```powershell
.\mvnw.cmd spring-boot:run
```

Validar:

```text
http://localhost:19051/swagger-ui/index.html
```

Crear una orden:

```powershell
Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:19051/api/v1/ordenes" `
  -ContentType "application/json" `
  -Body '{"usuarioId":1,"total":100}'
```

## Ver evento en Kafka

```powershell
cd C:\ms1\ProyectosMS2026\kafka
docker compose -f docker-compose-dev.yml exec kafka bash
```

```bash
/opt/kafka/bin/kafka-console-consumer.sh \
  --topic orden-eventos \
  --bootstrap-server kafka:9092 \
  --from-beginning
```

## Levantar PROD

Orden recomendado:

```powershell
cd C:\ms1\ProyectosMS2026\infra
docker compose up -d

cd C:\ms1\ProyectosMS2026\kafka
docker compose up -d

cd C:\ms1\ProyectosMS2026\services\orden-ms
docker compose up -d
```

En prod, `orden-ms` se conecta a:

- red interna propia: `orden-ms-net`
- red compartida: `ms-net`
- Config Server: `config-server:7071`
- Eureka: `registry-server:7081`
- Kafka: `kafka:9092`

## Variables PROD

- `SPRING_PROFILES_ACTIVE`
- `CONFIG_SERVER_URL`
- `KAFKA_BOOTSTRAP_SERVERS`
- `ORDEN_MS_DB_HOST`
- `ORDEN_MS_DB_PORT`
- `ORDEN_MS_DB_NAME`
- `ORDEN_MS_DB_USERNAME`
- `ORDEN_MS_DB_PASSWORD`
- `ORDEN_MS_MYSQL_ROOT_PASSWORD`
- `ORDEN_MS_MYSQL_DATABASE`

## Estado de avance

- [x] Microservicio `orden-ms`
- [x] Config Server
- [x] Registry Server (Eureka)
- [x] Base de datos MySQL dev/prod
- [x] API REST `/api/v1/ordenes`
- [x] Swagger/OpenAPI local
- [x] Integracion Kafka como producer
- [x] Publicacion de eventos en `orden-eventos`
- [x] Configuracion dev/prod centralizada
- [x] Observabilidad con Actuator/Prometheus
- [ ] Gestion avanzada de errores Kafka
- [ ] Integracion con frontend

---

## Tag sugerido

```bash
git tag -a vs09-kafka -m "eda con vs09-kafka"
git push origin vs09-kafka
```

# pago-ms

Microservicio de pagos con Spring Boot, MySQL y Kafka.

Consume eventos desde:

```text
orden-eventos
```

Procesa un pago simulado y publica el resultado en:

```text
pago-eventos
```

## Datos

```text
Group Id:     com.upeu
Artifact Id:  pago-ms
Package Name: com.upeu.pagoms
```

## Puertos

| Recurso | DEV | PROD |
|---|---:|---:|
| App | 19061 | 29061 |
| MySQL | 19060 | 29060 |

Kafka:

- dev host: `localhost:41092`
- prod Docker: `kafka:9092`

## Base de datos

```text
db_pago_ms
```

## Flujo

1. `orden-ms` publica `orden.creada` en `orden-eventos`
2. `pago-ms` consume ese evento
3. `pago-ms` guarda el pago en MySQL
4. `pago-ms` publica `pago.aprobado` o `pago.rechazado` en `pago-eventos`

## Archivos

- `docker-compose-dev.yml`: MySQL dev
- `docker-compose.yml`: app + MySQL prod
- `.env`: variables prod
- `src/main/resources/application.yml`: nombre de app, import de Config Server, topics y group id
- `../../infra/config-repo/pago-ms-dev.yml`: config dev centralizada
- `../../infra/config-repo/pago-ms-prod.yml`: config prod centralizada

## Levantar DEV

Primero infraestructura dev:

```powershell
cd C:\ms1\ProyectosMS2026\infra\config-server
.\mvnw.cmd spring-boot:run
```

En otra terminal:

```powershell
cd C:\ms1\ProyectosMS2026\infra\registry-server
.\mvnw.cmd spring-boot:run
```

Luego Kafka dev:

```powershell
cd C:\ms1\ProyectosMS2026\kafka
docker compose -f docker-compose-dev.yml up -d
```

Luego MySQL dev:

```powershell
cd C:\ms1\ProyectosMS2026\services\pago-ms
docker compose -f docker-compose-dev.yml up -d
```

Ejecutar la app:

```powershell
.\mvnw.cmd spring-boot:run
```

Validar:

```text
http://localhost:19061/api/v1/pagos/saludo
```

Respuesta esperada:

```text
pago-ms activo
```

## Levantar PROD

Orden recomendado:

```powershell
cd C:\ms1\ProyectosMS2026\infra
docker compose up -d

cd C:\ms1\ProyectosMS2026\kafka
docker compose up -d

cd C:\ms1\ProyectosMS2026\services\pago-ms
docker compose up -d
```

En prod, `pago-ms` se conecta a:

- red interna propia: `pago-ms-net`
- red compartida: `ms-net`
- Config Server: `config-server:7071`
- Eureka: `registry-server:7081`
- Kafka: `kafka:9092`

## Variables PROD

- `SPRING_PROFILES_ACTIVE`
- `CONFIG_SERVER_URL`
- `KAFKA_BOOTSTRAP_SERVERS`
- `PAGO_MS_DB_HOST`
- `PAGO_MS_DB_PORT`
- `PAGO_MS_DB_NAME`
- `PAGO_MS_DB_USERNAME`
- `PAGO_MS_DB_PASSWORD`
- `PAGO_MS_MYSQL_ROOT_PASSWORD`
- `PAGO_MS_MYSQL_DATABASE`

## Probar el flujo completo

1. Levantar Kafka.
2. Levantar MySQL dev de `orden-ms` y `pago-ms`.
3. Ejecutar `orden-ms`.
4. Ejecutar `pago-ms`.
5. Crear una orden en `orden-ms`.
6. Revisar logs de `pago-ms` o consumir `pago-eventos`.

## Estado de avance

- [x] Microservicio `pago-ms`
- [x] Config Server
- [x] Registry Server (Eureka)
- [x] Base de datos MySQL dev/prod
- [x] API REST `/api/v1/pagos`
- [x] Swagger/OpenAPI local
- [x] Integracion Kafka como consumer de `orden-eventos`
- [x] Integracion Kafka como producer de `pago-eventos`
- [x] Procesamiento automatico de pagos al recibir `EventoOrden`
- [x] Configuracion dev/prod centralizada
- [x] Observabilidad con Actuator/Prometheus
- [ ] Gestion avanzada de errores Kafka
- [ ] Integracion con frontend

---

## Tag sugerido

```bash
git tag -a vs09-kafka -m "eda con vs09-kafka"
git push origin vs09-kafka
```
